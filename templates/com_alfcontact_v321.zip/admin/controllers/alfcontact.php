<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// AlfContact Controller
class AlfcontactControllerAlfcontact extends JControllerForm
{
}
