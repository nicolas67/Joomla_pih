ALTER TABLE `#__alfcontact` DROP COLUMN `extra2`;
ALTER TABLE `#__alfcontact` MODIFY COLUMN `extra` TEXT;